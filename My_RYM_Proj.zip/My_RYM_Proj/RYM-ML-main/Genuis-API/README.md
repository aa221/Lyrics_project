# Lyrics_project
Analyzing the similarity of songs based on lyric usage. 
